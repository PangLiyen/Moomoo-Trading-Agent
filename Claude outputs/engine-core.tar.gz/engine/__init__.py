"""Deterministic trading engine core.

Layering, strictest first. Nothing in a lower layer imports a higher one.

    errors      vocabulary of refusal
    ledger      hash-chained append-only record
    config      fail-closed loader for risk_limits.yaml
    sizing      pure function: inputs -> quantity, with its arithmetic
    risk_gate   the last gate; may only tighten or refuse

No module here performs network I/O, reads free text, or consults a model.
That is what makes the limits enforceable rather than advisory.
"""

from .config import RiskConfig
from .errors import (
    AccountGuardError,
    ConfigError,
    EngineError,
    IntegrityError,
    RiskViolation,
    StaleDataError,
)
from .ledger import Ledger, file_sha256, write_genesis
from .risk_gate import AccountState, GateDecision, RiskGate, SessionState
from .sizing import SizingResult, size_position

__all__ = [
    "RiskConfig", "Ledger", "write_genesis", "file_sha256",
    "size_position", "SizingResult",
    "RiskGate", "AccountState", "SessionState", "GateDecision",
    "EngineError", "ConfigError", "AccountGuardError", "IntegrityError",
    "RiskViolation", "StaleDataError",
]
